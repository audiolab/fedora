BUILD STATUS
------------
Current build status:
[![Build Status](https://travis-ci.org/Islandora/islandora_solution_pack_audio.png?branch=7.x)](https://travis-ci.org/Islandora/islandora_solution_pack_audio)

CI Server:
http://jenkins.discoverygarden.ca

SUMMARY
-------

Audio Solution Pack

Adds all required Fedora objects to allow users to ingest and retrieve audio
files through the Islandora interface

REQUIREMENTS
------------

Lame - http://lame.sourceforge.net

INSTALLATION
------------

Ubuntu:
 * sudo apt-get install lame

CONFIGURATION
-------------


CUSTOMIZATION
-------------


TROUBLESHOOTING
---------------


F.A.Q.
------


CONTACT
-------


SPONSORS
--------
