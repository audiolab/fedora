<?php
/**
 * @file
 * Islandora solr map template.
 *
 * Variables available:
 * - $balloon: The unredered balloon markup for the object.
 * - $balloon_markup: The rendered balloon markup for the object.
 *
 * @see template_preprocess_islandora_solr_geo_balloon().
 */
?>

<?php print $balloon_markup; ?>
