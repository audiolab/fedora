<?php
/**
 * @file
 * Islandora solr map template.
 *
 * Variables available:
 * - $results: The rendered Solr results.
 *
 * @see template_preprocess_islandora_solr_geo_display_results().
 */
?>
<?php print $results; ?>